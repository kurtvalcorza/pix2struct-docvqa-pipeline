"""Row 63 review probes for tutorials/pix2struct_docvqa_colab.ipynb (pix2struct-docvqa-pipeline @ origin/main).

CPU only (CUDA_VISIBLE_DEVICES=-1). REDUCED SCALE: the adaptation probe uses a randomly initialised
Pix2Struct built from the repository's committed config with 12 decoder blocks (the pipeline hard-codes
DECODER_LAYERS = 12) but 32-wide, on tiny drawn pages -- never the pinned 282M checkpoint. It tests the
pipeline's state semantics, not answer quality. The corpus probe runs the repository's generator under the
probe environment's Pillow, which is NOT the notebook's pinned Pillow 11.3.0.

Usage: python run_probes.py <repo_root> <out_dir>
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
NB = REPO / "tutorials" / "pix2struct_docvqa_colab.ipynb"
results: dict = {"repo_root": str(REPO), "env": {"CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES")}}


def save():
    (OUT / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


# ---------------------------------------------------------------- static probes (source inspection)
nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
md = ["".join(c["source"]) for c in cells if c["cell_type"] == "markdown"]
code = [(i, "".join(c["source"])) for i, c in enumerate(cells) if c["cell_type"] == "code"]
alltext = "\n".join("".join(c["source"]) for c in cells)
compile_errors = []
for i, src in code:
    try:
        compile(src, f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors.append({"cell": i, "error": str(exc)})
blob = subprocess.run(["git", "-C", str(REPO), "rev-parse", "HEAD:tutorials/pix2struct_docvqa_colab.ipynb"],
                      capture_output=True, text=True).stdout.strip()
del_cell = next(i for i, s in code if re.search(r"^del pipe\b", s, re.M))
results["static"] = {
    "nbformat": [nb.get("nbformat"), nb.get("nbformat_minor")],
    "cells": len(cells), "code_cells": len(code),
    "compile_errors": compile_errors,
    "notebook_blob": blob,
    "metadata_dimer": nb["metadata"].get("dimer"),
    "outputs_present": sum(bool(c.get("outputs")) for c in cells if c["cell_type"] == "code"),
    "double_brace_in_markdown": [{"cell": i, "snippet": m.group(0)} for i, c in enumerate(cells)
                                 if c["cell_type"] == "markdown"
                                 for m in re.finditer(r"\{\{[^}]*\}\}", "".join(c["source"]))],
    "guided_markers": {k: bool(re.search(p, alltext, re.I)) for k, p in {
        "how_to_use": r"how to use this notebook", "roadmap": r"roadmap", "glossary": r"glossary",
        "troubleshooting": r"troubleshoot", "infrastructure_label": r"infrastructure",
        "predict_prompt": r"\bpredict\b(?!ion)|make a prediction", "check_your_reasoning": r"check your reasoning|<details",
        "what_to_notice": r"what to notice|expected result",
        "conclusion_template": r"conclusion template|your conclusion|write.*conclusion"}.items()},
    "cellView_form_cells": sum(c.get("metadata", {}).get("cellView") == "form" for c in cells),
    "embedded_module_cell_chars": {c["metadata"]["dimer"]["embedded_module"]: len("".join(c["source"]))
                                   for c in cells if c.get("metadata", {}).get("dimer", {}).get("embedded_module")},
    "env_var_DIMER_NOTEBOOK_CI_PREINSTALLED_in_code": "DIMER_NOTEBOOK_CI_PREINSTALLED" in "".join(s for _, s in code),
    "env_var_documented_in_markdown": any("DIMER_NOTEBOOK_CI_PREINSTALLED" in m for m in md),
    "restart_instruction_in_install_cell": "Restart the runtime" in code[0][1],
    "byod_uses_upload_dialog": "files.upload()" in alltext,
    "byod_location_field": bool(re.search(r"BYOD_(ZIP_)?PATH\s*=.*@param", alltext)),
    "byod_rerun_instruction_names_cells": bool(re.search(r"re-?run (from )?(section|cell)", alltext, re.I)),
    "del_pipe_cell": del_cell,
    "cells_using_pipe_before_del": [i for i, s in code if i < del_cell and re.search(r"\bpipe\.", s)],
    "pipe_built_only_in_cell": [i for i, s in code if re.search(r"^pipe = ", s, re.M)],
    "cuda_check_cell": next(i for i, s in code if "requires a CUDA GPU" in s),
    "model_download_cell": next(i for i, s in code if "stage_missing_files(WEIGHTS_DIR, allow_download=True)" in s),
    "runtime_estimate_in_markdown": bool(re.search(r"\b\d+\s*(s|sec|seconds|min|minutes|hours?)\b", "\n".join(md[:4]))),
    "ceiling_warning_in_markdown": bool(re.search(r"ceiling effect|at ceiling|already answers|saturat|cannot show an? (adaptation )?gain",
                                                  "\n".join(md), re.I)),
    "learner_activity_code_cells": [i for i, s in code if re.search(r"#\s*(TODO|your turn|exercise)", s, re.I)],
    "spec_version_declared": nb["metadata"].get("dimer", {}).get("notebook_spec"),
}
save()

sys.path.insert(0, str(REPO / "src"))
import PIL  # noqa: E402
from PIL import Image, ImageDraw  # noqa: E402

from pix2struct_docvqa_pipeline import samples as S  # noqa: E402

# ---------------------------------------------------------------- corpus probe
splits = S.build_sample_dataset()
recs_all = [r for rows in splits.values() for r in rows]
digest = S.dataset_digest(recs_all)
results["corpus"] = {
    "pillow_in_probe_env": PIL.__version__,
    "notebook_pins_pillow": "11.3.0",
    "split_counts": {k: len(v) for k, v in splits.items()},
    "distinct_documents": len({r["document_id"] for r in recs_all}),
    "distinct_question_strings": sorted({r["question"] for r in recs_all}),
    "digest_in_probe_env": digest,
    "SAMPLE_DIGEST": S.SAMPLE_DIGEST,
    "digest_matches": digest == S.SAMPLE_DIGEST,
    "note": "digest is Pillow-version dependent; a mismatch under a non-pinned Pillow is expected, not a defect",
}
save()


# ---------------------------------------------------------------- BYOD branch replay (no model)
def byod_block(uploaded: dict, work: Path):
    """Verbatim logic of the notebook's Section 4 BYOD branch (cell 13), files.upload() replaced by `uploaded`."""
    upload_name = next(iter(uploaded))
    p = work / upload_name
    p.write_bytes(uploaded[upload_name])
    records = S.load_byod_dataset(p)
    sp = S.split_dataset(records, seed=42)
    validated = {name: S.validate_dataset(rows) for name, rows in sp.items()}
    sp = {name: value["records"] for name, value in validated.items()}
    return S.check_split_disjoint(sp)


def png(colour, size=(96, 96)):
    buf = io.BytesIO()
    Image.new("RGB", size, colour).save(buf, format="PNG")
    return buf.getvalue()


def make_zip(entries):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for n, d in entries:
            z.writestr(n, d)
    return buf.getvalue()


def csv_text(n_docs, q_per_doc=3, folder="", drop_col=None):
    out = io.StringIO()
    cols = ["id", "document_id", "file", "question", "answers"]
    if drop_col:
        cols.remove(drop_col)
    w = csv.writer(out)
    w.writerow(cols)
    for d in range(n_docs):
        for q in range(q_per_doc):
            row = {"id": f"d{d}-q{q}", "document_id": f"doc{d}", "file": f"{folder}page{d}.png",
                   "question": f"What is field {q}?", "answers": f"A{d}{q}|a{d}{q}"}
            w.writerow([row[c] for c in cols])
    return out.getvalue()


def pages(n_docs, folder=""):
    return [(f"{folder}page{d}.png", png((d * 9 % 255, 120, 200))) for d in range(n_docs)]


cases = {
    "valid_20docs_nested_folders": make_zip([("data/records.csv", csv_text(20, folder="images/"))]
                                            + pages(20, "data/images/")),
    "cancelled_upload": None,
    "no_records_csv": make_zip(pages(20)),
    "missing_answers_column": make_zip([("records.csv", csv_text(20, drop_col="answers"))] + pages(20)),
    "non_image_page": make_zip([("records.csv", csv_text(20))] + pages(19) + [("page19.png", b"not an image")]),
    "small_10docs_30rows": make_zip([("records.csv", csv_text(10))] + pages(10)),
}
byod = {}
for name, payload in cases.items():
    with tempfile.TemporaryDirectory() as td:
        uploaded = {} if payload is None else {name + ".zip": payload}
        try:
            byod[name] = {"outcome": "accepted", "split_counts": byod_block(uploaded, Path(td))}
        except BaseException as exc:  # noqa: BLE001
            byod[name] = {"outcome": "error", "type": type(exc).__name__, "message": str(exc)[:240]}
results["byod_replay"] = byod
save()

# ---------------------------------------------------------------- stacked-adaptation probe (tiny random model)
import torch  # noqa: E402

torch.set_num_threads(2)
from transformers import Pix2StructConfig, Pix2StructForConditionalGeneration, Pix2StructProcessor  # noqa: E402

from pix2struct_docvqa_pipeline import pipeline as P  # noqa: E402

WD = REPO / "weights" / "pix2struct-docvqa-base"


def tiny(seed=0):
    processor = Pix2StructProcessor.from_pretrained(str(WD), local_files_only=True)
    processor.image_processor.max_patches = 64
    config = Pix2StructConfig.from_pretrained(str(WD), local_files_only=True)
    t, v = config.text_config, config.vision_config
    t.hidden_size, t.d_kv, t.num_heads, t.d_ff = 32, 8, 4, 64
    t.num_layers = 12  # pipeline hard-codes DECODER_LAYERS = 12 and adapts blocks 10, 11
    v.hidden_size, v.d_kv, v.num_attention_heads, v.d_ff, v.num_hidden_layers = 32, 8, 4, 64, 1
    config.text_config, config.vision_config = t, v
    torch.manual_seed(seed)
    model = Pix2StructForConditionalGeneration(config).eval()
    for p_ in model.parameters():
        p_.requires_grad_(False)
    font = P.header_font_bytes()

    def runner(image, question, max_new_tokens):
        inputs = processor.image_processor(image, header_text=question, return_tensors="pt", font_bytes=font)
        with torch.inference_mode():
            gen = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
        return {"answer": processor.tokenizer.batch_decode(gen, skip_special_tokens=True)[0],
                "new_tokens": int(gen[0].shape[0]) - 1}

    return P.Pix2StructDocVQAPipeline(runner, "cpu", "float32", "tiny-random", _model=model,
                                      _processor=processor, _font_bytes=font)


P.MAX_PATCHES = 64  # reduced scale: training inputs at 64 patches instead of 2048
records = []
for i in range(10):
    im = Image.new("RGB", (128, 96), "white")
    ImageDraw.Draw(im).text((10, 40), f"TOTAL {100 + i}", fill="black")
    records.append({"id": f"r{i}", "document_id": f"doc{i}", "image": im, "question": "What is the total?",
                    "answers": [f"{100 + i}"]})

pipe = tiny()
base = {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}
LR = 1e-3
r1 = pipe.adapt(records, None, epochs=1, lr=LR, batch_size=5, trainable_decoder_layers=2)
after1 = {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}
# "Next experiments: compare one versus two trainable decoder blocks": edit Section 6 and rerun it before
# Section 8 (same pipe object).
r2 = pipe.adapt(records, None, epochs=1, lr=LR, batch_size=5, trainable_decoder_layers=1)
after2 = {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}
layer10 = [k for k in base if k.startswith("decoder.layer.10.")]


def changed(a, b, keys):
    return sum(not torch.equal(a[k], b[k]) for k in keys)


work = Path(tempfile.mkdtemp())
art = work / "adapter"
pipe.save_artifact(art)
fresh = tiny()
fresh.load_artifact(art)
fs = fresh._model.state_dict()
mismatch = [k for k in after2 if not torch.equal(after2[k].cpu(), fs[k].cpu())]
control = tiny()  # what re-running Section 3 does: a new pipeline from the base snapshot
control_equal_base = all(torch.equal(base[k], v) for k, v in control._model.state_dict().items())
manifest = json.loads((art / "manifest.json").read_text())
results["stacked_adaptation"] = {
    "scale": "REDUCED: 12-decoder-block/32-wide random Pix2Struct from the committed config, 10 tiny drawn pages, "
             "no validation split (selection = final epoch so weights move; the notebook passes a validation split), "
             "CPU, MAX_PATCHES=64, lr=1e-3, 1 epoch each",
    "run1": {"trainable_decoder_layers": 2, "best_epoch": r1["best_epoch"], "n_trainable": r1["n_trainable"]},
    "run2": {"trainable_decoder_layers": 1, "best_epoch": r2["best_epoch"], "n_trainable": r2["n_trainable"],
             "epoch0_note": r2["history"][0].get("note")},
    "run1_changed_tensors_vs_base": changed(base, after1, list(base)),
    "run2_started_from_base": all(torch.equal(base[k], after1[k]) for k in base),
    "decoder_layer10_tensors_changed_vs_base_after_run2": changed(base, after2, layer10),
    "decoder_layer10_tensor_count": len(layer10),
    "artifact_tensors": len(manifest["tensors"]),
    "artifact_layers_recorded": manifest["adapter"]["trainable_decoder_layers"],
    "reloaded_vs_inmemory_mismatched_tensors": len(mismatch),
    "reloaded_vs_inmemory_mismatched_examples": mismatch[:5],
    "rebuild_pipeline_restores_base": control_equal_base,
    "interpretation": "adapt() starts from the pipeline's current weights and labels epoch 0 'frozen model'; a second "
                      "adapt() with fewer blocks leaves first-run changes in block 10, which the new artifact does not "
                      "export, so the artifact no longer reproduces the in-memory model. Rebuilding the pipeline "
                      "(re-running Section 3) restores the base.",
}
save()
print(json.dumps(results, indent=2, default=str)[:7000])
